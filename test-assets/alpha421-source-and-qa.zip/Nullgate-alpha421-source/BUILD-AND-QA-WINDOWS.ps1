$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$localPython = Join-Path $env:LOCALAPPDATA "Programs\Python\Python313\python.exe"
if (Test-Path $localPython) { $python = $localPython }
elseif (Get-Command python -ErrorAction SilentlyContinue) { $python = (Get-Command python).Source }
elseif (Get-Command py -ErrorAction SilentlyContinue) { $python = (Get-Command py).Source }
else { throw "Python 3 missing. Install Python and/or update PATH." }
if (-not (Get-Command javac -ErrorAction SilentlyContinue)) { throw "JDK javac missing from PATH." }
if (-not (Get-Command java -ErrorAction SilentlyContinue)) { throw "Java missing from PATH." }
& $python .\build_release.py
if ($LASTEXITCODE -ne 0) { throw "Build failed." }
& $python .\qa\run_qa.py
if ($LASTEXITCODE -ne 0) { throw "QA failed." }
