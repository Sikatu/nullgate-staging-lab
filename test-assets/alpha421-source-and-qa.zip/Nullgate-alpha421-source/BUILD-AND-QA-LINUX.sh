#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 build_release.py
python3 qa/run_qa.py
