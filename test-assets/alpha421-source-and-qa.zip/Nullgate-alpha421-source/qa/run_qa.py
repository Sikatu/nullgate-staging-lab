#!/usr/bin/env python3
from pathlib import Path
import subprocess, zipfile, hashlib, json, sys, os, time, shutil
R=Path(__file__).resolve().parent.parent
BASE=R/'artifacts/BASE.jar'
J=R.parent.parent/'Nullgate-0.1.0-alpha.4.21-GUI-ASYNC-PERMISSION-GUARD-STAGING.jar'
T=R/'artifacts/tests'
T.mkdir(exist_ok=True)
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.util=ALL-UNNAMED']
def run(a):
 p=subprocess.run(a,capture_output=True,text=True,timeout=90)
 if p.returncode:raise RuntimeError('ERROR '+str(a)+'\n'+p.stdout+'\n'+p.stderr)
 return p.stdout.strip()
run(['javac',*flags,'-d',str(T),str(R/'tests/BytecodeAudit.java'),str(R/'tests/GuiPatchRegression.java'),str(R/'tests/ApiRegressionAudit.java')])
run(['javac','--release','21','-d',str(T),str(R/'tests/stubs/org/bukkit/entity/Player.java'),str(R/'src/com/ellipsissmp/nullgate/admin/GuiAccessPolicy.java'),str(R/'tests/GuiAccessPolicyLoadTest.java'),str(R/'tests/stubs/org/bukkit/event/Listener.java'),str(R/'tests/ClassLoadSmoke.java')])
logs=[]
for k in range(1,4):
 t=time.monotonic()
 a=run(['java','-ea','-Xverify:all','-cp',str(T),'GuiAccessPolicyLoadTest'])
 b=run(['java',*flags,'-Xverify:all','-cp',str(T),'GuiPatchRegression',str(BASE),str(J)])
 c=run(['java',*flags,'-Xverify:all','-cp',str(T),'BytecodeAudit',str(J)])
 e=run(['java',*flags,'-Xverify:all','-cp',str(T),'ApiRegressionAudit',str(J)])
 d=run(['java','-Xverify:all','-cp',str(T)+os.pathsep+str(J),'ClassLoadSmoke'])
 logs.append(f'PASS {k} ({time.monotonic()-t:.3f}s): {a} | {b} | {c} | {d} | {e}')
(R/'qa/three-pass-results.txt').write_text('\n'.join(logs)+'\n')
with zipfile.ZipFile(BASE) as b,zipfile.ZipFile(J) as z:
 old={n:hashlib.sha256(b.read(n)).hexdigest() for n in b.namelist() if not n.endswith('/')}
 new={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}
 changed={n for n in old.keys()&new.keys() if old[n]!=new[n]}
 added=set(new.keys())-set(old.keys())
 expected={'com/ellipsissmp/nullgate/admin/AdminGuiService.class','plugin.yml','config.yml','META-INF/MANIFEST.MF'}
 assert changed==expected,(changed,expected)
 assert added=={'com/ellipsissmp/nullgate/admin/GuiAccessPolicy.class'},added
 assert not (old.keys()-new.keys())
 for n in old:
  if n.startswith(('com/ellipsissmp/nullgate/antibot/','com/ellipsissmp/nullgate/identity/','com/ellipsissmp/nullgate/auth/','com/ellipsissmp/nullgate/database/','com/ellipsissmp/nullgate/security/','com/ellipsissmp/nullgate/continuity/')):assert old[n]==new[n],'unexpected security/account/antibot drift: '+n
 for n in ('plugin.yml','config.yml','META-INF/MANIFEST.MF'):
  assert b'0.1.0-alpha.4.21' in z.read(n)
 assert b'Implementation-Version: 0.1.0-alpha.4.21' in z.read('META-INF/MANIFEST.MF')
 for x in [b'createPasswordAccount',b'resetPasswordForReregistration',b'bindVerifiedPremiumIdentity',b'applyNLoginMigration']:
  assert x not in z.read('com/ellipsissmp/nullgate/admin/GuiAccessPolicy.class'),x
 first=hashlib.sha256(J.read_bytes()).hexdigest()
 run([sys.executable,str(R/'build_release.py')]);second=hashlib.sha256(J.read_bytes()).hexdigest()
 assert first==second,'JAR not reproducible'
 report={'baseline_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'candidate_sha256':first,'changed_original_entries':sorted(changed),'added_entries':sorted(added),'three_passes':logs,'verdict':'STAGING ONLY; runtime Purpur/Java25 not verified; binary patch, not canonical source'}
 (R/'qa/release-integrity.json').write_text(json.dumps(report,indent=2)+'\n')
 print('\n'.join(logs))
 print('PASS byte-identical deterministic rebuild',first)
 print('PASS anti-bot, authentication, identity, database, security and continuity class bytes unchanged')
