# Nullgate alpha.4.21 — QA Report

## Scope

Baseline v0.1.0-alpha.4.20, patched bytecode of `AdminGuiService` (9 delayed permission-check points), new `GuiAccessPolicy` class, updated version metadata only. No player databases were read or modified.

## Three independent QA passes

Each pass runs the **actual compiled** `GuiAccessPolicy` class with stubbed `Player` methods: 800,000 authorization decisions under 16 concurrent submitting threads; expected 200,000 allow and 600,000 deny. At each pass, ASM verifies nine patched method entrances with operation-specific permissions and the unpatched alpha.4.20 baseline as negative control. Full structural and operand-stack checks cover 137 classes and 1,581 concrete methods. Minimal Bukkit stubs permit a JVM class-loading check (`Class.forName`, without live invocation of the GUI code). A known-signature scan verifies 16 historical API-sensitive method calls and absence of direct uncached skull-owner assignments.

See `three-pass-results.txt` and `release-integrity.json` for reproducible observations and checksums.

## Diff integrity

Only original JAR entries `AdminGuiService.class`, `plugin.yml`, `config.yml`, `META-INF/MANIFEST.MF` change, and only new class `GuiAccessPolicy.class` is added. All original anti-bot, auth, database, continuity, identity, and security class bytes are **identical** to the alpha.4.20 baseline. The JAR rebuilds with the same SHA-256.

## Inferences and not-yet-tested items

- No live Purpur 1.21.11 / Java 25 load, Minecraft admin GUI click, real SQLite timing, actual networked players, anti-bot attack simulator or Bedrock crossplay was possible in the local environment. **Do not extrapolate isolated throughput to server TPS**.
- The regression audit validates the expected *injected control-flow entry*, not complete authorization of every admin operation. Existing in-progress database writes are not transactionally canceled; already visible inventories remain visible until closed.
- The test Player implementation represents permission and connectivity decisions, **not complete Paper event execution**.
- Without the original canonical source and full exact dependencies, the binary build cannot be designated production-ready.

**Verdict: PASS for this scoped offline patch, STAGING ONLY; production release and full alpha.4.21 milestone certification remain blocked.**
