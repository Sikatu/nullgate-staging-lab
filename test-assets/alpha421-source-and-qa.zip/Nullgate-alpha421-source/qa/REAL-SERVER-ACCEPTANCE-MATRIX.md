# Mandatory Real Purpur 1.21.11 / Java 25 Acceptance Matrix — NOT YET RUN

| Scenario | Expected | Actual | Gate |
|---|---|---|---|
| Full startup: one Nullgate JAR, all dependencies | No missing methods/classes, enabled cleanly | Not tested | BLOCKED |
| `/ng gui` main + profiles and navigation | No exceptions or GUI item movement | Not tested | BLOCKED |
| Permission revoked during `loadAdminAccountSummaries` | No delayed privileged GUI opens | Not tested | BLOCKED |
| Permission revoked while opening IP/linked accounts | No delayed sensitive data display | Not tested | BLOCKED |
| Permission revoked while ban/IP ban request pending | No new action after revocation; existing writes separately assessed | Not tested | BLOCKED |
| Anti-bot legitimate PvP/vehicles/teleports/portals | No meaningful false positives | Not tested | BLOCKED |
| Connection floods and disconnect/reconnect | Bounded work/queues, no bypass, no staff false positives | Not tested | BLOCKED |
| Java Premium valid/invalid Mojang proof | Fresh verified proof on each reconnect, rejects forgery | Not tested | BLOCKED |
| Cracked Java registration/login/recovery | Password required, retries fail closed, no lost records | Not tested | BLOCKED |
| Floodgate Bedrock authenticated identity | No Java spoof/mis-link, expected auto-auth | Not tested | BLOCKED |
| Offline vs Premium UUIDs; CMI/LuckPerms | Preserve all original data and report conflicts; never auto-merge | Not tested | BLOCKED |
| Real TPS/MSPT and memory soak | Release SLOs under representative load | Not tested | BLOCKED |

Use **throwaway staging accounts**, never stress the public authentication endpoint without server-owner authorization and isolation.
