# Nullgate v1.0.0 production path — build checkpoint

- alpha.4.20: read-only UUID continuity scan — isolated QA passed, live validation pending.
- **alpha.4.21:** privileged admin GUI delayed-callback permission recheck — isolated QA passed; anti-bot and real GUI integration still **not certified**.
- alpha.4.21 follow-on: precise Purpur 1.21.11 ABI/JDK25 and live GUI permission-revocation test, anti-bot legitimate false-positive and abuse simulation, real Bedrock/Java trust matrix.
- alpha.4.22: measurable multiplayer load and soak test using throwaway accounts; database, TPS/MSPT/memory, GUI and connection pressure.
- v1.0.0-RC.1: clean canonical full-source build, independent security review, rollback, data ownership checks, complete acceptance evidence.
- v1.0.0: owner-approved canary, monitored rollout, no critical/high open vulnerabilities.

**Canonical Java project remains missing.** The patcher is an audited intermediate, not a foundation for a long-term production binary patch chain.
