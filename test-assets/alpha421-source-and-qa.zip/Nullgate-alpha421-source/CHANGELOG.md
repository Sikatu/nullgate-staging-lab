# Nullgate development history — alpha.4.21

## v0.1.0-alpha.4.21 (2026-10-17) — Async GUI authorization hardening

- **FIX:** nine privileged, delayed GUI/moderation callbacks now recheck `isOnline()` and their operation-specific permission on the main thread.
- **SECURITY:** permission revoked during pending read now suppresses privileged GUI result instead of rendering sensitive data.
- **QA:** new executable authorization policy, 9-callback negative/positive bytecode regression, 16 known-sensitive API method descriptor audit, 3 repeated load passes, ASM class verification, reproducible binary patch.
- **NO CHANGE:** Premium Java handshake, password hashing, account records, UUID binding, authentication deadlines, continuity scanning, anti-bot algorithms, and data/schema structure.
- **STATUS:** private staging only. Broader anti-bot GUI workflow and Purpur 1.21.11/Java 25 integration remain open.
