package org.bukkit.entity;
public interface Player { boolean isOnline(); boolean hasPermission(String permission); }
