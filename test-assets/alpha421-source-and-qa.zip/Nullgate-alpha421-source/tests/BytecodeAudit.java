import java.util.*;import java.util.zip.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.util.CheckClassAdapter;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.tree.analysis.*;
public final class BytecodeAudit {
 public static void main(String[] args)throws Exception {
  int classes=0,methods=0;
  try(ZipFile z=new ZipFile(args[0])){
   for(ZipEntry e:Collections.list(z.entries())){
    if(!e.getName().endsWith(".class"))continue;
    byte[] data=z.getInputStream(e).readAllBytes();
    new ClassReader(data).accept(new CheckClassAdapter(new ClassWriter(0),false),0);classes++;
    ClassNode cn=new ClassNode();new ClassReader(data).accept(cn,0);
    for(MethodNode m:cn.methods){ if(m.instructions.size()==0)continue;
     try{new Analyzer<>(new BasicVerifier()).analyze(cn.name,m);methods++;}
     catch(Exception ex){throw new AssertionError(cn.name+"#"+m.name+m.desc,ex);}
    }
   }
  }
  System.out.println("PASS ASM structural/stack: "+classes+" classes, "+methods+" methods");
 }
}
