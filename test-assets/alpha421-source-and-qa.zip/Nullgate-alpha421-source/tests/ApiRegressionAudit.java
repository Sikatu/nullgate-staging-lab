import java.util.*;import java.util.zip.*;
import jdk.internal.org.objectweb.asm.*;
public final class ApiRegressionAudit {
 static final Map<String,String> required=Map.ofEntries(
  Map.entry("org/bukkit/event/vehicle/VehicleExitEvent#getExited", "()Lorg/bukkit/entity/LivingEntity;"),
  Map.entry("org/bukkit/event/entity/EntityPickupItemEvent#getEntity", "()Lorg/bukkit/entity/LivingEntity;"),
  Map.entry("org/bukkit/event/entity/FoodLevelChangeEvent#getEntity", "()Lorg/bukkit/entity/HumanEntity;"),
  Map.entry("org/bukkit/event/inventory/InventoryOpenEvent#getPlayer", "()Lorg/bukkit/entity/HumanEntity;"),
  Map.entry("org/bukkit/event/inventory/InventoryClickEvent#getWhoClicked", "()Lorg/bukkit/entity/HumanEntity;"),
  Map.entry("org/bukkit/event/vehicle/VehicleEnterEvent#getEntered", "()Lorg/bukkit/entity/Entity;"),
  Map.entry("org/bukkit/entity/Player#openInventory", "(Lorg/bukkit/inventory/Inventory;)Lorg/bukkit/inventory/InventoryView;")
 );
 public static void main(String[]a)throws Exception{
  int[] checked={0};List<String> bad=new ArrayList<>();Set<String> seen=new TreeSet<>();
  try(ZipFile z=new ZipFile(a[0])){
   for(ZipEntry e:Collections.list(z.entries())){
    if(!e.getName().endsWith(".class"))continue;
    new ClassReader(z.getInputStream(e).readAllBytes()).accept(new ClassVisitor(Opcodes.ASM9){
     @Override public MethodVisitor visitMethod(int ac,String name,String descriptor,String sig,String[] exceptions){
      return new MethodVisitor(Opcodes.ASM9){
       @Override public void visitMethodInsn(int opcode,String owner,String method,String desc,boolean itf){
        String key=owner+"#"+method;
        if(required.containsKey(key)){
         checked[0]++;seen.add(key);
         if(!required.get(key).equals(desc))bad.add(e.getName()+" "+name+": "+key+desc+" expected "+required.get(key));
        }
        if(owner.equals("org/bukkit/inventory/meta/SkullMeta") && method.equals("setOwningPlayer"))bad.add("Uncached owner assignment in "+e.getName());
       }
      };
     }
    },0);
   }
  }
  if(!bad.isEmpty())throw new AssertionError(bad.toString());
  if(!seen.contains("org/bukkit/event/vehicle/VehicleExitEvent#getExited")|| !seen.contains("org/bukkit/event/inventory/InventoryClickEvent#getWhoClicked"))throw new AssertionError("Regressions missed key signatures: "+seen);
  System.out.println("PASS "+checked[0]+" known-sensitive API call sites and zero uncached skull owner methods; NOT a full ABI check");
 }
}
