import java.util.*;import java.util.zip.*;import java.nio.file.*;
import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
import static jdk.internal.org.objectweb.asm.Opcodes.*;
public final class GuiPatchRegression {
 static final Map<String,String> perms=Map.ofEntries(
 Map.entry("lambda$openMain$5","nullgate.admin.gui"),
 Map.entry("lambda$openPlayer$0","nullgate.admin.inspect"),
 Map.entry("lambda$openProfile$7","nullgate.admin.inspect"),
 Map.entry("lambda$openActions$9","nullgate.admin.inspect"),
 Map.entry("lambda$openIpHistory$11","nullgate.admin.inspect"),
 Map.entry("lambda$openLinked$13","nullgate.admin.alts.view"),
 Map.entry("lambda$openIpBanConfirm$15","nullgate.admin.ipban"),
 Map.entry("lambda$performIpBan$25","nullgate.admin.ipban"),
 Map.entry("lambda$handleBanToggle$17","nullgate.admin.ban"));
 static byte[] cls(String file)throws Exception{
  try(ZipFile z=new ZipFile(file)){
   ZipEntry e=z.getEntry("com/ellipsissmp/nullgate/admin/AdminGuiService.class");return z.getInputStream(e).readAllBytes();
  }
 }
 static Map<String,MethodNode> methods(byte[] bytes){
  ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);
  Map<String,MethodNode> m=new HashMap<>();for(MethodNode n:c.methods)m.put(n.name,n);return m;
 }
 static boolean guarded(MethodNode m,String p){
  if(m==null)return false; int step=0;String found=null;
  for(AbstractInsnNode i=m.instructions.getFirst();i!=null&&step<8;i=i.getNext()){
   if(i.getOpcode()<0)continue;
   if(step==0 && i instanceof VarInsnNode v && v.getOpcode()==ALOAD && v.var==((m.access & ACC_STATIC)==0?1:0)){step++;continue;}
   if(step==1 && i instanceof LdcInsnNode l && p.equals(l.cst)){step++;continue;}
   if(step==2 && i instanceof MethodInsnNode v && v.getOpcode()==INVOKESTATIC && v.owner.equals("com/ellipsissmp/nullgate/admin/GuiAccessPolicy") && v.name.equals("permitted") && v.desc.equals("(Lorg/bukkit/entity/Player;Ljava/lang/String;)Z")){step++;continue;}
   if(step==3 && i instanceof JumpInsnNode v && v.getOpcode()==IFNE){step++;continue;}
   if(step==4 && i.getOpcode()==RETURN){return true;}
   return false;
  }
  return false;
 }
 public static void main(String[] a)throws Exception{
  Map<String,MethodNode> baseline=methods(cls(a[0])),candidate=methods(cls(a[1]));int checked=0;
  for(var e:perms.entrySet()){
   if(guarded(baseline.get(e.getKey()),e.getValue()))throw new AssertionError("negative control falsely guarded "+e.getKey());
   if(!guarded(candidate.get(e.getKey()),e.getValue()))throw new AssertionError("missing corrected guard "+e.getKey());
   checked++;
  }
  System.out.println("PASS "+checked+" guarded callbacks; baseline negative controls confirmed");
 }
}
