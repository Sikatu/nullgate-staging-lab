import com.ellipsissmp.nullgate.admin.GuiAccessPolicy;
import org.bukkit.entity.Player;
import java.lang.reflect.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
public final class GuiAccessPolicyLoadTest {
 static final class P implements Player {
  volatile boolean online;volatile boolean permission; P(boolean a,boolean b){online=a;permission=b;}
  public boolean isOnline(){return online;}
  public boolean hasPermission(String p){return permission && p.startsWith("nullgate.admin.");}
 }
 public static void main(String[]args)throws Exception {
  String perm="nullgate.admin.inspect";
  if(GuiAccessPolicy.permitted(null,perm))throw new AssertionError("null viewer");
  if(GuiAccessPolicy.permitted(new P(true,true),null))throw new AssertionError("null permission");
  P p=new P(true,true);
  if(!GuiAccessPolicy.permitted(p,perm))throw new AssertionError("valid staff");
  p.permission=false;if(GuiAccessPolicy.permitted(p,perm))throw new AssertionError("revoked privilege");
  p.permission=true;p.online=false;if(GuiAccessPolicy.permitted(p,perm))throw new AssertionError("disconnected");
  p.online=true;
  ExecutorService pool=Executors.newFixedThreadPool(16); AtomicInteger deny=new AtomicInteger();AtomicInteger allow=new AtomicInteger();
  java.util.List<Future<?>> pending=new java.util.ArrayList<>();
  for(int t=0;t<16;t++){
    final int thread=t;pending.add(pool.submit(()->{
      P actor=new P(thread%2==0,thread%4==0);
      for(int i=0;i<50000;i++){
         if(GuiAccessPolicy.permitted(actor,perm))allow.incrementAndGet();else deny.incrementAndGet();
      }
    }));
  }
  for(Future<?> f:pending)f.get();pool.shutdown();
  if(allow.get()!=200000||deny.get()!=600000)throw new AssertionError("unexpected auth counts: "+allow+","+deny);
  System.out.println("PASS 800000 authorization decisions: 200000 allow, 600000 deny");
 }
}
