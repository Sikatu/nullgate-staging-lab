# Nullgate v0.1.0-alpha.4.21 — Admin GUI async permission safety

**Author: Sikatu | ◍ ◍ ◍ | PRIVATE STAGING — not production certified**

## Verified defect and change

In alpha.4.20, several sensitive `AdminGuiService` completion callbacks returned from database reads to the main Bukkit thread and checked only `Player.isOnline()`. A permission revoked after submission but before completion did not prevent those callbacks from presenting an administrative inventory or continuing a moderation action. This build injects a **second check** immediately at the start of each of nine main-thread callback implementations. The check requires a non-null, online player and the **same operation-specific permission** that its initial request required.

Affected completion handlers:

- `lambda$openMain$5` — `nullgate.admin.gui`
- `lambda$openPlayer$0`, `lambda$openProfile$7`, `lambda$openActions$9`, `lambda$openIpHistory$11` — `nullgate.admin.inspect`
- `lambda$openLinked$13` — `nullgate.admin.alts.view`
- `lambda$openIpBanConfirm$15`, `lambda$performIpBan$25` — `nullgate.admin.ipban`
- `lambda$handleBanToggle$17` — `nullgate.admin.ban`

The check is **fail-closed**; if authorization disappears during the database request, the delayed callback returns without rendering data or starting subsequent operations. No new permissions are added. Existing GUI click cancellation and original initial permission checks remain unchanged.

### Important limitations

- This patch does **not** retroactively close an administrative inventory already displayed before a permission change. It prevents the selected **delayed completions** from opening or progressing after revocation.
- It does **not** cancel database operations already in progress, and does not revoke a moderation write after the underlying write started; those require transaction-aware design and live testing.
- It does **not** redesign anti-bot algorithms. The entire `antibot/` package is preserved byte-for-byte. Verification of behavior-guard, rate limits, false positives, and real Geyser/Floodgate traffic remains an open milestone.
- It does **not** audit all Bukkit/Purpur API calls against the exact runtime JAR. The offline ABI audit checks only 16 known-sensitive invocation sites.
- This is a reproducible **binary patch of alpha.4.20**, **not a full canonical Java source tree**. The current project still needs a clean source rebuild using the official Paper/Purpur API.

## Build and verification

From this folder on Linux: `bash BUILD-AND-QA-LINUX.sh`; on Windows PowerShell: `.\BUILD-AND-QA-WINDOWS.ps1`. Prerequisites: Java/JDK 21 or newer, `javac`, `java`, Python 3. Python must be available on Windows via `py -3` or `python` or installed under `%LOCALAPPDATA%\Programs\Python\Python313\python.exe`.

The script strictly pins the baseline JAR's SHA-256 and preserves all other class entries. It builds `../../Nullgate-0.1.0-alpha.4.21-GUI-ASYNC-PERMISSION-GUARD-STAGING.jar`. No online dependency fetch is required. The exact previous JAR is included in `artifacts/BASE.jar`.

The tests include: a 9-handler ASM patch audit with an unpatched negative control; three repetitions of 800,000 permission decisions; 137-class/1,581-method structural and stack analysis; class loading under `-Xverify:all` with minimal Bukkit interfaces; an invocation descriptor regression scan; anti-bot/database/authentication byte-for-byte preservation; and deterministic rebuild SHA-256.

## Installation, staging acceptance and rollback

1. **Private staging only.** Stop Purpur and back up the entire `plugins/Nullgate` directory, authentication database, encryption keys, server configuration, LuckPerms/CMI and player data.
2. Remove the alpha.4.20 plugin JAR (keep a separate offline backup); install only the alpha.4.21 JAR and fully restart. Never delete an authentication DB or UUID binding to accommodate a plugin upgrade.
3. Run `/ng gui`, navigate the main page, a player profile, IP history, linked account details, ban/IP-ban confirmation, and test an administrator permission revocation while a delayed GUI database query is pending. Confirm unauthorized pages do not open. Check console for Java linkage errors.
4. Test legitimate Premium Java (fresh Mojang proof each reconnect), cracked Java (password required), and Floodgate Bedrock identities; run `/ng performance` and inspect TPS/MSPT, CPU, and memory. These live tests **have not been performed** here.
5. If a problem occurs, stop staging and restore alpha.4.20 with intact account data and keys. Restore database snapshots only when operationally safe; blindly restoring an earlier DB can discard legitimate registrations made after the snapshot.

**PRODUCTION: NO GO.** Full canonical source, official Java 25/Purpur runtime tests, real Java/Bedrock security acceptance, performance and anti-bot false-positive testing remain unverified.
