package com.ellipsissmp.nullgate.admin;
import org.bukkit.entity.Player;
/** Rechecks the original view authorization on Bukkit's main thread before an async GUI completion renders.
 * Never caches a permission decision or moves Bukkit API calls to the async DB thread. */
public final class GuiAccessPolicy {
    private GuiAccessPolicy() {}
    public static boolean permitted(Player viewer, String requiredPermission) {
        return viewer != null && requiredPermission != null
            && viewer.isOnline() && viewer.hasPermission(requiredPermission);
    }
}
