#!/usr/bin/env python3
import hashlib, pathlib, shutil, subprocess, zipfile
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'artifacts/BASE.jar'
EXPECTED=(ROOT/'artifacts/BASELINE.sha256').read_text().strip()
assert hashlib.sha256(BASE.read_bytes()).hexdigest()==EXPECTED, 'baseline SHA mismatch'
DEST=ROOT.parent.parent/'Nullgate-0.1.0-alpha.4.21-GUI-ASYNC-PERMISSION-GUARD-STAGING.jar'
CLASSES=ROOT/'artifacts/classes'; WORK=ROOT/'artifacts/work'
for p in [CLASSES,WORK]:shutil.rmtree(p,ignore_errors=True);p.mkdir(parents=True)
source=ROOT/'src/com/ellipsissmp/nullgate/admin/GuiAccessPolicy.java'
stub=ROOT/'tests/stubs/org/bukkit/entity/Player.java'
subprocess.run(['javac','--release','21','-d',str(CLASSES),str(stub),str(source)],check=True)
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
subprocess.run(['javac',*flags,'-d',str(CLASSES),str(ROOT/'patcher/PatchAdminGui421.java')],check=True)
with zipfile.ZipFile(BASE) as b:b.extractall(WORK)
path=WORK/'com/ellipsissmp/nullgate/admin/AdminGuiService.class'
subprocess.run(['java',*flags,'-cp',str(CLASSES),'PatchAdminGui421',str(path)],check=True)
new_class=CLASSES/'com/ellipsissmp/nullgate/admin/GuiAccessPolicy.class'
assert new_class.exists()
for name in ('plugin.yml','config.yml','META-INF/MANIFEST.MF'):
 p=WORK/name;before=p.read_bytes();assert b'0.1.0-alpha.4.20' in before,name
 p.write_bytes(before.replace(b'0.1.0-alpha.4.20',b'0.1.0-alpha.4.21'))
# Preserve all entries, metadata, order, compression and unchanged bytes.  Append helper only.
with zipfile.ZipFile(BASE) as inp,zipfile.ZipFile(DEST,'w') as out:
 old=set()
 for entry in inp.infolist():
  old.add(entry.filename)
  file=WORK/entry.filename
  out.writestr(entry,b'' if entry.is_dir() else file.read_bytes())
 newname='com/ellipsissmp/nullgate/admin/GuiAccessPolicy.class'
 assert newname not in old
 info=zipfile.ZipInfo(newname,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
 out.writestr(info,new_class.read_bytes())
print('BUILT',DEST,'BYTES',DEST.stat().st_size,'SHA256',hashlib.sha256(DEST.read_bytes()).hexdigest())
