import java.nio.file.*;
import java.util.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import static jdk.internal.org.objectweb.asm.Opcodes.*;
/** Binary-only patch. Recheck page-specific privileges in synchronous completion handlers. */
public final class PatchAdminGui421 {
  private static final Map<String,String> PERMISSIONS = Map.ofEntries(
    Map.entry("lambda$openMain$5", "nullgate.admin.gui"),
    Map.entry("lambda$openPlayer$0", "nullgate.admin.inspect"),
    Map.entry("lambda$openProfile$7", "nullgate.admin.inspect"),
    Map.entry("lambda$openActions$9", "nullgate.admin.inspect"),
    Map.entry("lambda$openIpHistory$11", "nullgate.admin.inspect"),
    Map.entry("lambda$openLinked$13", "nullgate.admin.alts.view"),
    Map.entry("lambda$openIpBanConfirm$15", "nullgate.admin.ipban"),
    Map.entry("lambda$performIpBan$25", "nullgate.admin.ipban"),
    Map.entry("lambda$handleBanToggle$17", "nullgate.admin.ban")
  );
  public static void main(String[] args)throws Exception {
    if(args.length!=1) throw new IllegalArgumentException("requires AdminGuiService.class");
    Path path=Path.of(args[0]); ClassNode cls=new ClassNode(ASM9);
    new ClassReader(Files.readAllBytes(path)).accept(cls,0);
    if(!cls.name.equals("com/ellipsissmp/nullgate/admin/AdminGuiService")) throw new AssertionError("wrong class");
    Set<String> visited = new HashSet<>();
    for(MethodNode method:cls.methods){
      String perm=PERMISSIONS.get(method.name); if(perm==null)continue;
      if(!visited.add(method.name))throw new AssertionError("ambiguous method "+method.name);
      if(!method.desc.startsWith("(Lorg/bukkit/entity/Player;") || !method.desc.endsWith(")V"))
        throw new AssertionError("unexpected callback signature: "+method.name+method.desc);
      int p=((method.access & ACC_STATIC)!=0)?0:1;
      LabelNode allowed = new LabelNode(); InsnList prep=new InsnList();
      prep.add(new VarInsnNode(ALOAD,p));
      prep.add(new LdcInsnNode(perm));
      prep.add(new MethodInsnNode(INVOKESTATIC,"com/ellipsissmp/nullgate/admin/GuiAccessPolicy","permitted","(Lorg/bukkit/entity/Player;Ljava/lang/String;)Z",false));
      prep.add(new JumpInsnNode(IFNE,allowed));
      prep.add(new InsnNode(RETURN));
      prep.add(allowed);
      prep.add(new FrameNode(F_SAME,0,null,0,null));
      method.instructions.insert(prep);
    }
    if(!visited.equals(PERMISSIONS.keySet()))throw new AssertionError("missing methods "+PERMISSIONS.keySet().stream().filter(x->!visited.contains(x)).toList());
    ClassWriter cw=new ClassWriter(ClassWriter.COMPUTE_MAXS);cls.accept(cw);Files.write(path,cw.toByteArray());
    System.out.println("Guarded "+visited.size()+" delayed GUI continuations: "+visited);
  }
}
